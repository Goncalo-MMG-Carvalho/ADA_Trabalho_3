
public class Edge {
	 public int capacity;
	 public int destiny;
	 
	 public Edge(int capacity ,int destiny) {
		 this.capacity = capacity;
		 this.destiny = destiny;
	 }
	 
	 public int getC() {
		 return this.capacity;
	 }
	 
	 public int getD() {
		 return this.destiny;
	 }
}
