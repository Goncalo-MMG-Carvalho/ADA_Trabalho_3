import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		String[] firstLine = input.readLine().split(" ");
		int numRegions = Integer.parseInt(firstLine[0]);
		int numLinks = Integer.parseInt(firstLine[1]);

		List<List<Integer>> regions = new ArrayList<>((numRegions*2) + 1); // +1 because of the artificial node //alterado

		for (int i = 0; i <= (numRegions*2); i++) { //alterado
			regions.add(i, new ArrayList<>((numRegions*2) + 1));
			for (int j = 0; j <= numRegions*2; j++) {
		        regions.get(i).add(0);
		    }
		}//aloca espaco para num regioes * 2  + 1 
			

		int[] capacityStoradge = new int[(numRegions*2) + 1];
		capacityStoradge[0] = 0;
		
		List<Integer> artList = regions.get(0); // artificial node
		artList.set(0,Integer.MAX_VALUE); 		//just to add a indiferent value for the 0 to 0 position
		//set
		for (int i = 1; i <= numRegions; i++) {
			firstLine = input.readLine().split(" "); // we used firstLine again just for convenience
			int populationSize = Integer.parseInt(firstLine[0]);
			int departureCapacity = Integer.parseInt(firstLine[1]);

			artList.set(i,populationSize);//set

			capacityStoradge[i] = departureCapacity;
//            List<Integer> regionList = regions.get(i);
//            regionList.add(0, departureCapacity); 
			regions.get(i).set(0, capacityStoradge[0]); // initialize the flow links of the artificial node to zero
			
			regions.get(i).set(i+numRegions, departureCapacity); 
			//dois nos para cada regiao um de entrada outro de saida e ligados por um arco com peso igual departure capacity 
		}
		for (int i = 0; i < numLinks; i++) {
			firstLine = input.readLine().split(" "); // we used firstLine again just for convenience
			int r1 = Integer.parseInt(firstLine[0]);
			int r2 = Integer.parseInt(firstLine[1]);

			regions.get(r1+numRegions).set(r2, capacityStoradge[r1]); //alterado 
			regions.get(r2+numRegions).set(r1, capacityStoradge[r2]); //alterado
		}

		int safeRegion = Integer.parseInt(input.readLine());
		int result = edmondsKarp(regions , 0 , safeRegion, (numRegions*2)+1); // a safe reigion e o no de entrada da regiao safe nao faz sentido ser o de saida
		input.close();
		System.out.println(result);
	}

	public static int edmondsKarp(List<List<Integer>> network, int source, int sink, int numNodes) {
		int[][] flow = new int[numNodes][numNodes]; // inicializar o flow de cada vertice a zero
//		for (int i = 0; i <= numNodes; i++) 
//			for (int j = 0; j <= numNodes; i++)
//				flow[i][j] = 0;
		int[] via = new int[numNodes];
		int flowValue = 0;
		int increment;
		while ((increment = findPath(network, flow, source, sink, via, numNodes)) != 0) {
			flowValue += increment;
			// Update flow.
			int node = sink;
			while (node != source) {
				int origin = via[node];
				flow[origin][node] += increment;
				flow[node][origin] -= increment;
				node = origin;
			}
		}
		return flowValue; // return new PairClass<>(flowValue, flow);
	}

	private static int findPath(List<List<Integer>> network, int[][] flow, int source, int sink, int[] via, int numNodes) {
		Queue<Integer> waiting = new LinkedList<>();
		boolean[] found = new boolean[numNodes]; // java initializes the matrix with false
//		for every Node v in network.nodes()
//		found[v] = false;
		int[] pathIncr = new int[numNodes];
		waiting.add(source);
		found[source] = true;
		via[source] = source;
		pathIncr[source] = Integer.MAX_VALUE; // pensar
		do {
			int origin = waiting.remove(); // certa
			List<Integer> originList = network.get(origin);
//			for every Edge<L> e in network.outIncidentEdges(origin) {
//			Node destin = e.secondNode();	
			int destin = 0; //destin ta quase certo
			for (Integer capacity : originList) {
				int residue = /*e.label()*/ capacity - flow[origin][destin];
				if (!found[destin] && residue > 0) {
					via[destin] = origin;
					pathIncr[destin] = Math.min(pathIncr[origin], residue);
					if (destin == sink)
						return pathIncr[destin];
					waiting.add(destin);
					found[destin] = true;
				}
				destin++; //destin ta quase certo
			}
		} while (!waiting.isEmpty());
		return 0;
	}

}